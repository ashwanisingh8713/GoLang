//go:build !gocql_debug
// +build !gocql_debug

package gocql

const gocqlDebug = false
